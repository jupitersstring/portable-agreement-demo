import test from 'node:test';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {mkdtemp,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {fileURLToPath} from 'node:url';
import * as P from '../site/protocol.mjs';
import {examples,example} from '../site/examples.mjs';
const python=process.env.AGREEMENT_REFERENCE_PYTHON;
const bridge=fileURLToPath(new URL('./reference_bridge.py',import.meta.url));
test('human examples are inert valid terms; editing a chosen form cannot mutate a preset',async()=>{
 const customer=await P.identity(),provider=await P.identity();
 for(const [name,preset] of Object.entries(examples)){
  const draft=example(name);draft.task='Customer-specific draft';
  assert.equal(examples[name].task,preset.task);
  let order=await P.draft({task:preset.task,customer:customer.public,provider:provider.public,quantity:preset.quantity,deadline:1900000000,orderNonce:'a'.repeat(64)});
  order=await P.assent(order,customer);assert.equal((await P.inspect(order,order.id)).status,'PROPOSED');
  order=await P.assent(order,provider);assert.equal((await P.inspect(order,order.id)).status,'BOUND');
  assert.equal(order.body.terms.task,preset.task);assert.equal(order.body.terms.quantity,preset.quantity);
 }
 assert.throws(()=>example('constructor'),/UNKNOWN_EXAMPLE/);
});
async function made(){const c=await P.identity(),p=await P.identity();let o=await P.draft({task:'SYNTHETIC: deliver a three-source research report.',customer:c.public,provider:p.public,quantity:90,deadline:1900000000,orderNonce:'a'.repeat(64)});o=await P.assent(o,c);return {c,p,o};}
async function bound(){const x=await made();x.o=await P.assent(x.o,x.p);return x;}
const code=name=>error=>error.code===name;
const bundle=(o,evidence=[])=>({format:P.BUNDLE,selected:o.id,agreements:[o],evidence});
const reference=value=>JSON.parse(execFileSync(python,[bridge],{input:JSON.stringify(value),encoding:'utf8',timeout:15000,env:process.env}));

test('a signed offer is not bound until separate provider acceptance',async()=>{const {o,c,p}=await made();assert.equal((await P.inspect(o,o.id)).status,'PROPOSED');await assert.rejects(P.event(o,p,'DELIVERY_CLAIM','b'.repeat(64)),code('OPEN_WORK_NOT_BOUND'));await assert.rejects(P.assent(o,c),code('OPEN_WORK_ASSENT'));const both=await P.assent(o,p);const state=await P.inspect(both,both.id);assert.equal(state.status,'BOUND');assert.equal(state.payment_verified,false);assert.equal(state.execution_authorized,false);assert.equal(c.private.extractable,false);});
test('changed price cannot retain the identifier or the previous signatures',async()=>{const {o}=await bound(),old=structuredClone(o),changed=structuredClone(o);changed.body.terms.quantity=130;await assert.rejects(P.inspect(changed,o.id),code('OPEN_WORK_CHANGED'));changed.id=await P.digest(P.LABEL,changed.body);await assert.rejects(P.inspect(changed,changed.id),code('SIGNATURE'));assert.deepEqual(o,old);assert.equal((await P.inspect(o,o.id)).status,'BOUND');});
test('a revision binds its parent and needs new acceptance while old evidence remains intact',async()=>{const {o,c,p}=await bound();let revised=await P.draft({task:o.body.terms.task,customer:c.public,provider:p.public,quantity:130,deadline:1900000000,context:{amends:o.id},orderNonce:'d'.repeat(64)});revised=await P.assent(revised,c);assert.notEqual(o.id,revised.id);assert.equal((await P.inspect(revised,revised.id)).status,'PROPOSED');revised=await P.assent(revised,p);const report=await P.verifyBundle({format:P.BUNDLE,selected:revised.id,agreements:[o,revised],evidence:[]});assert.equal(report.results.length,2);assert.equal(o.body.terms.quantity,90);assert.equal(revised.body.terms.quantity,130);});
test('delivery, receipt and dispute have ordered signed links with role checks',async()=>{const {o,c,p}=await bound();await assert.rejects(P.event(o,c,'DELIVERY_CLAIM','b'.repeat(64),1800000000),code('OPEN_WORK_EVENT_AUTHORITY'));let next=await P.event(o,p,'DELIVERY_CLAIM','b'.repeat(64),1800000000);next=await P.event(next,c,'DISPUTE','c'.repeat(64),1800000001);const state=await P.inspect(next,next.id);assert.equal(state.events,2);assert.equal(state.delivery_verified,false);const bad=structuredClone(next);bad.events.reverse();await assert.rejects(P.inspect(bad,bad.id),code('OPEN_WORK_EVENT_CHAIN'));const forged=structuredClone(next);forged.events[0].body.evidence='f'.repeat(64);await assert.rejects(P.inspect(forged,forged.id),code('SIGNATURE'));await assert.rejects(P.event(next,c,'RECEIPT','d'.repeat(64),1800000000),code('OPEN_WORK_CLOCK_ORDER'));});
test('a bundle is portable public data; evidence is optional and independently checked',async()=>{const {o,c,p}=await bound();const text='SYNTHETIC report\nA unicode evidence note: Δ',hash=await P.contentHash(text);const delivered=await P.event(o,p,'DELIVERY_CLAIM',hash,1800000000);const wire=JSON.stringify(bundle(delivered));assert.equal(wire.includes('private'),false);const reopened=P.parseJSON(wire);assert.equal((await P.verifyBundle(reopened,{expectedId:o.id})).selected.status,'BOUND');await assert.rejects(P.verifyBundle(reopened,{expectedId:'f'.repeat(64)}),code('DEMO_PIN_MISMATCH'));const withText=bundle(delivered,[{sha256:hash,text}]);assert.equal((await P.verifyBundle(withText)).includedEvidence,1);withText.evidence[0].text+=' changed';await assert.rejects(P.verifyBundle(withText),code('DEMO_EVIDENCE_CHANGED'));});
test('import parsing refuses duplicate keys, fractional numbers, oversized and nested payloads',()=>{assert.throws(()=>P.parseJSON('{"price":90,"price":130}'),code('DUPLICATE_KEY'));assert.throws(()=>P.parseJSON('{"price":1e3}'),code('NONINTEGER_NUMBER'));assert.throws(()=>P.parseJSON('{"price":-0}'),code('INTEGER_RANGE'));assert.throws(()=>P.parseJSON(' '.repeat(P.LIMIT+1)),code('INPUT_LIMIT'));assert.throws(()=>P.parseJSON('['.repeat(30)+'0'+']'.repeat(30)),code('DEMO_STRUCTURE_LIMIT'));assert.equal(Object.getPrototypeOf(P.parseJSON('{"__proto__":{"polluted":true}}')),null);assert.equal({}.polluted,undefined);});
test('byte framing is canonical with numeric-looking keys, quotes, slashes, booleans and null',()=>{assert.equal(P.canonical({'2':'second','10':'first','x':'"\\/',enabled:true,none:null}),'{'+'"10":"first","2":"second","enabled":true,"none":null,"x":"\\"\\\\/"'+'}');assert.throws(()=>P.canonical({a:'line\nbreak'}),code('ASCII_PROFILE'));assert.throws(()=>P.canonical({a:1.1}),code('INTEGER_RANGE'));});
test('malicious authority claims, foreign keys and extra signed fields fail closed',async()=>{const {o}=await bound();let bad=structuredClone(o);bad.execution_authorized=true;await assert.rejects(P.inspect(bad,bad.id),code('OPEN_WORK_CLAIMS'));bad=structuredClone(o);bad.body.terms.execute=true;await assert.rejects(P.inspect(bad,bad.id),code('FIELDS'));bad=structuredClone(o);bad.body.provider='00'.repeat(32);await assert.rejects(P.inspect(bad,bad.id),code('OPEN_WORK_DISTINCT_PARTIES'));});
test('browser-generated records verify in the actual Python reference',{skip:!python},async()=>{const {o,c,p}=await bound();let next=await P.event(o,p,'DELIVERY_CLAIM','b'.repeat(64),1800000000);next=await P.event(next,c,'DISPUTE','c'.repeat(64),1800000001);const results=reference({action:'verify',agreements:[o,next]});assert.deepEqual(results,[await P.inspect(o,o.id),await P.inspect(next,next.id)]);});
test('actual Python-generated signed records verify with browser WebCrypto',{skip:!python},async()=>{const order=reference({action:'make'});const result=await P.inspect(order,order.id);assert.equal(result.status,'BOUND');assert.equal(result.events,2);const changed=structuredClone(order);changed.events[1].body.at++;await assert.rejects(P.inspect(changed,changed.id),code('SIGNATURE'));});
test('a separate command-line process verifies an exported record and refuses wrong pins and edits',async()=>{
 const {o}=await bound(),dir=await mkdtemp(join(tmpdir(),'agreement-demo-test-')),file=join(dir,'record.json'),cli=fileURLToPath(new URL('../verify_record.mjs',import.meta.url));
 try{
  await writeFile(file,JSON.stringify(bundle(o)));
  const result=JSON.parse(execFileSync(process.execPath,[cli,file,o.id],{encoding:'utf8'}));assert.equal(result.selected.status,'BOUND');assert.equal(result.independent_fingerprint_supplied,true);
  assert.throws(()=>execFileSync(process.execPath,[cli,file,'f'.repeat(64)],{stdio:'pipe'}),error=>error.status===1&&error.stderr.toString().includes('DEMO_PIN_MISMATCH'));
  o.body.terms.quantity++;await writeFile(file,JSON.stringify(bundle(o)));
  assert.throws(()=>execFileSync(process.execPath,[cli,file],{stdio:'pipe'}),error=>error.status===1&&error.stderr.toString().includes('OPEN_WORK_CHANGED'));
 }finally{await rm(dir,{recursive:true,force:true});}
});
